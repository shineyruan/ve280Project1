#ifndef __RAND_H__
#define __RAND_H__

void p1_srand(int);
// EFFECTS: initializes the seed
int p1_rand();
// EFFECTS: returns a random number between 0 and 32767

#endif /* __RAND_H__ */
