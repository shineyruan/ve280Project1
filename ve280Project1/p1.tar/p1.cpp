#include <iostream>
#include <string>
#include "p1.h"
using namespace std;

int main() {
	char ch;
	int score = 0;

	//Generate seed to choose a word.
	int seed;
	cout << "Please input seed: ";
	cin >> seed;
	p1_srand(seed);

	//Construct the answer word, the guess word (initialized with '_ _ _ _ _ _')
	int r = p1_rand() % nWords;
	string ans = words[r];
	string guess = "", proposed = "";
	for (unsigned int i = 0; i < ans.length(); i++) guess += '_';
	
	while (1) {
		//Construct judging varaibles: flag denotes whether the customer has guessed the right character. 
		bool proposed_repeat = 0, isvalid = 0, flag = 0;

		//Display contents. 
		cout << "Score: " << score << endl;
		for (unsigned int i = 0; i < guess.length(); i++) cout << guess[i] << " ";
		cout << endl
			<< "Already proposed characters: " << endl;
		for (unsigned int i = 0; i < proposed.length(); i++) cout << proposed[i] << " ";
		cout << endl
			<< "Please enter a letter (a-z): ";

		//Input prompt of the character. 
		cin >> ch;
		if ((ch >= 'a') && (ch <= 'z')) isvalid = 1;

		//Judging if it is a correct character. 
		for (unsigned int i = 0; i < ans.length(); i++)
			if (ch == ans[i]) {
				flag = 1;
				guess[i] = ans[i];
			}

		//If not, add the character into proposed[]. 
		if (flag == 0)
			if ((isvalid) && (proposed.length() == 0)) proposed += ch;
			else {
				//Insert the character into proposed[].
				for (unsigned int i = 0; i < proposed.length(); i++) {
					if (ch == proposed[i]) { proposed_repeat = 1; break; }
					else if (isvalid) {
						if (ch < proposed[i]) {
							proposed.insert(i, 1, ch);
							break;
						}
					}
				}
				//If the character is the biggest, append it to proposed[].
				if ((isvalid) && (!proposed_repeat) && (ch > proposed.back())) proposed += ch;
			}

		//Compute scores. 
		if ((flag == 0) && (isvalid) && (!proposed_repeat)) score++;

		//Conditions of jumping out the loop.
		if (score >= 10) {
			cout << "The word was: " << ans << endl
				<< "You lost!" << endl;
			break;
		}
		else if (guess == ans) {
			cout << "The word was: " << ans << endl
				<< "You won!" << endl;
			break;
		}
	}

	return 0;
}